package com.demo;

import dev.codefortress.core.easy_licensing.TrialAwareLicenseValidator;
import dev.codefortress.core.easy_licensing.LicenseCheckResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoreDemoApp implements CommandLineRunner {

    @Autowired
    private TrialAwareLicenseValidator validator;

    public static void main(String[] args) {
        SpringApplication.run(CoreDemoApp.class, args);
    }

    @Override
    public void run(String... args) {
        LicenseCheckResult result = validator.validate("usuario@demo.com", "secreta", "demo-project");
        System.out.println("Resultado de la licencia: " + result.getStatus());
        System.out.println("Mensaje: " + result.getMessage());
    }
}
