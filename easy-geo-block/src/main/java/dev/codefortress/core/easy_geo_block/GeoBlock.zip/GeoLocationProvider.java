package dev.codefortress.core.easy_geo_block;

public interface GeoLocationProvider {
    String resolveCountryCode(String ip);
}
